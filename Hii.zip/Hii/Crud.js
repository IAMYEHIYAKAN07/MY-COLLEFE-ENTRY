function save() {
 const contactList = JSON.parse(localStorage.getItem("listItem")) ?? [];
  var id;
  contactList.length != 0
    ? contactList.findLast((item) => (id = item.id))
    : (id = 0);

  if (document.getElementById("id").value) {
    contactList.forEach((value) => {
      if (document.getElementById("id").value == value.id) {
        (value.name = document.getElementById("name").value),
          (value.email = document.getElementById("email").value),
          (value.address = document.getElementById("address").value),
          (value.phone = document.getElementById("phone").value);
      }
    });

    document.getElementById("id").value = "";
  } else {
    const item = {
      id: id + 1,
      name: document.getElementById("name").value,
      email: document.getElementById("email").value,
      address: document.getElementById("address").value,
      phone: document.getElementById("phone").value,
    };
    //add item data to array contactlist
    contactList.push(item);
  }

  localStorage.setItem("listItem", JSON.stringify(contactList));
  document.getElementById("form").reset();

  window.location.href = "/AnotherData.html";
  allData();
}


